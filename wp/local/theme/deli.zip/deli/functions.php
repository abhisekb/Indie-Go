<?php
/**
 * Deli engine room
 *
 * @package deli
 */

/**
 * Initialize all the things.
 */
require get_stylesheet_directory() . '/inc/init.php';
